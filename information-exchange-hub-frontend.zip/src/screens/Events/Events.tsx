import React from 'react'

type Props = {}

function Events({}: Props) {
  return (
    <div>Events</div>
  )
}

export default Events