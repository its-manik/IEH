import React from 'react'

type Props = {}

function Webhooks({}: Props) {
  return (
    <div>Webhooks</div>
  )
}

export default Webhooks