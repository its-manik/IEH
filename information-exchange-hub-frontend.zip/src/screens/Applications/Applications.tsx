import React from 'react'

type Props = {}

function Applications({}: Props) {
  return (
    <div>Applications</div>
  )
}

export default Applications