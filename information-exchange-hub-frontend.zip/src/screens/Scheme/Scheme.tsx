import React from 'react'

type Props = {}

function Scheme({}: Props) {
  return (
    <div>Scheme</div>
  )
}

export default Scheme