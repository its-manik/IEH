import React from 'react'

type Props = {}

function Dashboard({}: Props) {
  return (
    <div>Dashboard</div>
  )
}

export default Dashboard