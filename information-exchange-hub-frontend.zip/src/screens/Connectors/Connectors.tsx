import React from 'react'

type Props = {}

function Connectors({}: Props) {
  return (
    <div>Connectors</div>
  )
}

export default Connectors