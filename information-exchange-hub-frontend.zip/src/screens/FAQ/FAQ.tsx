import React from 'react'

type Props = {}

function FAQ({}: Props) {
  return (
    <div>FAQ</div>
  )
}

export default FAQ