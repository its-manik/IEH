import React from 'react'

type Props = {}

function Activities({}: Props) {
  return (
    <div>Activities</div>
  )
}

export default Activities