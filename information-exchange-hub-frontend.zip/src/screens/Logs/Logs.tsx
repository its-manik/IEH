import React from 'react'

type Props = {}

function Logs({}: Props) {
  return (
    <div>Logs</div>
  )
}

export default Logs