import React from 'react'

type Props = {}

function ControlPanel({}: Props) {
  return (
    <div>ControlPanel</div>
  )
}

export default ControlPanel